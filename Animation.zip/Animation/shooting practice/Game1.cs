﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input.Touch;
using shooting_practice;


namespace shooting_practice
{
   /// <summary>
   /// This is the main type for your game.
   /// </summary>
   public class Game1 : Game
   {
      GraphicsDeviceManager graphics;
      SpriteBatch spriteBatch;

      Player player;
      public float playerMoveSpeed;
      KeyboardState CurrentKeyboardState;
      KeyboardState PreviousKeyboardState;
      GamePadState CurrentGamePadState;
      GamePadState PreviousGamePadState;
      ParallaxingBackground bgLayer1;
      ParallaxingBackground bgLayer2;
    
      Texture2D mainBackground;
      Rectangle rectBackground;
      

      public Game1()
      {
         graphics = new GraphicsDeviceManager(this);
        // graphics.PreferredBackBufferWidth = 800;
         //graphics.PreferredBackBufferHeight = 800;
         Content.RootDirectory = "Content";
      }

      /// <summary>
      /// Allows the game to perform any initialization it needs to before starting to run.
      /// This is where it can query for any required services and load any non-graphic
      /// related content.  Calling base.Initialize will enumerate through any components
      /// and initialize them as well.
      /// </summary>
      protected override void Initialize()
      {
         // TODO: Add your initialization logic here
         player = new Player();
         rectBackground = new Rectangle(0,0,GraphicsDevice.Viewport.Width,GraphicsDevice.Viewport.Height);
         bgLayer1 = new ParallaxingBackground();
         bgLayer2 = new ParallaxingBackground();
        
         playerMoveSpeed = 8f;
      //   TouchPanel.EnabledGestures = GestureType.FreeDrag;
         base.Initialize();
      }

      /// <summary>
      /// LoadContent will be called once per game and is the place to load
      /// all of your content.
      /// </summary>
      protected override void LoadContent()
      {
         // Create a new SpriteBatch, which can be used to draw textures.
         spriteBatch = new SpriteBatch(GraphicsDevice);
         Animation PlayerAnimation = new Animation();
         Texture2D PlayerTexture = Content.Load<Texture2D>("Dragon2Animation");
         PlayerAnimation.Initialize(PlayerTexture, Vector2.Zero, 162,150,8,120,Color.White,1f,true);
         Vector2 PlayerPosition = new Vector2(GraphicsDevice.Viewport.TitleSafeArea.X, GraphicsDevice.Viewport.TitleSafeArea.Y + GraphicsDevice.Viewport.Height/2);
         player.Initialize(PlayerAnimation,PlayerPosition);
        // Vector2 playerPosition = new Vector2(GraphicsDevice.Viewport.TitleSafeArea.X, GraphicsDevice.Viewport.TitleSafeArea.Y+GraphicsDevice.Viewport.TitleSafeArea.Height/2);
         //player.Initialize(Content.Load<Texture2D>("player"), playerPosition);
         bgLayer1.Initialize(Content, "spacebgLayer1", GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height, 10);

         bgLayer2.Initialize(Content, "spacebgLayer2", GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height, 20);
       
         mainBackground = Content.Load<Texture2D>("spacemainbackground");



      }

      /// <summary>
      /// UnloadContent will be called once per game and is the place to unload
      /// game-specific content.
      /// </summary>
      protected override void UnloadContent()
      {
         // TODO: Unload any non ContentManager content here
      }

      /// <summary>
      /// Allows the game to run logic such as updating the world,
      /// checking for collisions, gathering input, and playing audio.
      /// </summary>
      /// <param name="gameTime">Provides a snapshot of timing values.</param>
      protected override void Update(GameTime gameTime)
      {
         PreviousKeyboardState = CurrentKeyboardState;
         PreviousGamePadState = CurrentGamePadState;
         CurrentKeyboardState = Keyboard.GetState();
         CurrentGamePadState = GamePad.GetState(PlayerIndex.One);
         if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();
         UpdatePlayer(gameTime);

         // TODO: Add your update logic here
         player.Update(gameTime);
         base.Update(gameTime);
      }
      private void UpdatePlayer(GameTime gameTime)
      {
         if(CurrentKeyboardState.IsKeyDown(Keys.Left)|| CurrentGamePadState.DPad.Left==ButtonState.Pressed)
         {
            player.Position.X -= playerMoveSpeed;
         }
         if (CurrentKeyboardState.IsKeyDown(Keys.Right)|| CurrentGamePadState.DPad.Right==ButtonState.Pressed)
         {
            player.Position.X += playerMoveSpeed;
         }
         if (CurrentKeyboardState.IsKeyDown(Keys.Up)| CurrentGamePadState.DPad.Up==ButtonState.Pressed)
         {
            player.Position.Y -= playerMoveSpeed;
          }
         if (CurrentKeyboardState.IsKeyDown(Keys.Down)||CurrentGamePadState.DPad.Down==ButtonState.Pressed)
         {
            player.Position.Y +=playerMoveSpeed;
         }
       //  player.Position.X = MathHelper.Clamp(player.Position.X, 0, GraphicsDevice.Viewport.Width - player.Width);
        // player.Position.Y = MathHelper.Clamp(player.Position.Y, 0, GraphicsDevice.Viewport.Height - player.Height);
         player.Position.X = MathHelper.Clamp(player.Position.X, -20, GraphicsDevice.Viewport.Width - (player.PlayerAnimation.FrameWidth-30));

         player.Position.Y = MathHelper.Clamp(player.Position.Y, -20, GraphicsDevice.Viewport.Height - (player.PlayerAnimation.FrameHeight-30));

      }

      /// <summary>
      /// This is called when the game should draw itself.
      /// </summary>
      /// <param name="gameTime">Provides a snapshot of timing values.</param>
      protected override void Draw(GameTime gameTime)
      {
         GraphicsDevice.Clear(Color.CornflowerBlue);
         spriteBatch.Begin();
         spriteBatch.Draw(mainBackground, rectBackground, Color.White);
         // Draw the moving background
         bgLayer1.Draw(spriteBatch);
         bgLayer2.Draw(spriteBatch);
        
         player.Draw(spriteBatch);
         spriteBatch.End();

         // TODO: Add your drawing code here

         base.Draw(gameTime);
      }
   }
}

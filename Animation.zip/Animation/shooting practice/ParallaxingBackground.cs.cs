﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input.Touch;
namespace shooting_practice
{
   class ParallaxingBackground
   {
      Vector2[] Positions;
      Texture2D texture;
      int speed;
      private int bgWidth;
      private int bgHeight;
      public void Initialize(ContentManager content, String texturePath, int screenWidth, int screenHeight, int speed)
      {
         bgHeight = screenHeight;
         bgWidth = screenWidth;
         texture = content.Load<Texture2D>(texturePath);
         this.speed = speed;
         Positions=new Vector2[screenWidth/texture.Width+1];
         for (int i=0; i<Positions.Length;i++)
         {
            Positions[i] = new Vector2(i*texture.Width,0);
         }

      }
      public void Update(GameTime gameTime)
      {
         for (int i=0; i<Positions.Length;i++)
         {
            Positions[i].X += speed;
            if (speed<=0)
            {
               if(Positions[i].X <= - texture.Width)
               {
                  Positions[i].X = texture.Width * (Positions.Length - 1);
                }
            }
            else
            {
               if(Positions[i].X >= texture.Width * (Positions.Length-1))
               {
                  Positions[i].X = - texture.Width;
               }
            }
         }
      }
      public void Draw(SpriteBatch spriteBatch)
      {
         for(int i=0; i<Positions.Length; i++)
         {
            Rectangle rectBg = new Rectangle((int)Positions[i].X, (int)Positions[i].Y, bgWidth, bgHeight);
            spriteBatch.Draw(texture,rectBg,Color.White);
         }
      }
   }
}
